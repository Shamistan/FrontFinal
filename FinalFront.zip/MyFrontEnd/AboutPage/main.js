$(function () {
    $("#ourvision .col-md-3 ul li").click(function (e) {
        
        $("#ourvision .col-md-3 ul li").removeClass("activli")
        var actives = $(this);
        if (!actives.hasClass("activLi")) {
            $(actives).addClass("activLi");
        }
    })
    $(".fa-bars").click(function () {
        $(".rightNav").css({ "top": "0px", "right": "0px" });
        $(".contentDiv").css("display", "block");
    })
    $(".fa-times-circle").click(function () {
        $(".rightNav").css("right", "-250px");
        $(".contentDiv").css("display", "none");

    })

    $(window).scroll(function () {
        var $this = $(this),
            $head = $('#head');
        if ($this.scrollTop() > 200) {
          
          $(".colAbout .col-md-4 .title h3").css("animation-name", "fadeInLeft");
          $(".colAbout .col-md-4 .title p").css("animation-name", "fadeInLeft");
          $(".colHed .col-md-4 h1").css("animation-name", "fadeInLeft");
          
          
        } 
    });

    $(window).scroll(function () {
        var $this = $(this),
            $head = $('#head');
        if ($this.scrollTop() > 1300) {
          
          $(".collTeam .divTeamImg").css("animation-name", "fadeInLeft");
          $(".collTeam  ul li").css("animation-name", "fadeInLeft");
          $(".collTeam  p").css("animation-name", "fadeInLeft");
          
          
        } 
    });

    $(".hed .nacColl .nav .uls ul  li ").first().addClass("active");

    $(".hed .nacColl .nav .uls ul  li ").click(function (e) {

        $(".hed .nacColl .nav .uls ul li ").removeClass("active");

        var actives = $(this);
        if (!actives.hasClass("active")) {
            actives.addClass("active");
        }

    });

    // Activ Class Li
    $("#ourvision .container .rowSection2 .col-md-3 ul  li ").first().addClass("activLi");

    $("#ourvision .container .rowSection2 .col-md-3 ul  li ").click(function (e) {

        $("#ourvision .container .rowSection2 .col-md-3 ul li ").removeClass("activLi");

        var actives = $(this);
        if (!actives.hasClass("activLi")) {
            actives.addClass("activLi");
        }

    });
    // Activ Class Li
     //Li Click
     $("#ourvision .container .rowSection2 .col-md-3 ul  li ").first().click(function(){
         
         $(".div1").css("display","block");
         $(".div2").css("display","none");
         $(".div3").css("display","none");
        
     });
     $("#ourvision .container .rowSection2 .col-md-3 ul  li ").first().next().click(function(){
         
        $(".div2").css("display","block");
        $(".div1").css("display","none");
        $(".div3").css("display","none");
       
    })
    $("#ourvision .container .rowSection2 .col-md-3 ul  li ").last().click(function(){
      
        $(".div3").css("display","block");
        $(".div2").css("display","none");
        $(".div1").css("display","none");
       
    })
     //Li Click
     


    $(".owl-carousel").owlCarousel({
        loop: true,
        margin: 25,
        center: true,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 1
            }
        }


    });
    

});
