$(function(){
$(".fa-bars").click(function(){
  $(".rightNav").css({"top":"0px","right":"0px"});
  $(".contentDiv").css("display","block");
})
$(".fa-times-circle").click(function(){
    $(".rightNav").css("right","-250px");
    $(".contentDiv").css("display","none");
    
})


$(".hed .nacColl .nav .uls ul  li ").first().addClass("active");

$(".hed .nacColl .nav .uls ul  li ").click(function (e) {

    $(".hed .nacColl .nav .uls ul li ").removeClass("active");

    var actives = $(this);
    if (!actives.hasClass("active")) {
        actives.addClass("active");
    }

});
// Modal//
$(".activImages").click(function () {
    $(".modal").css({ "display": "block", "opacity": "1", "transition": "0.4s linear" });
    $("#photo_modal").attr("src", $(this).next().attr("src"));
    $(this).next().addClass("act")
});

$(".fa-times").click(function () {
    $(".modal").css("display", "none");
});
// Modal//


// Modal RightClick //
$(".fas.fa-angle-right").click(function(){
    var imgactiv = $(".act");
    imgactiv.removeClass("act");
    var nextElemImg=imgactiv.parent().next().find(".im");
    var NextDivImg=imgactiv.parent().parent().parent().next().find(".divimg").find("div:first-child").find(".im");
    var FisrtImg=$(".col-md-9 .col-md-3:first-child .divimg .divimg1 .im");
  

   if(nextElemImg.length===1){  
       
    $("#photo_modal").attr("src", nextElemImg.attr("src"));
    nextElemImg.addClass("act");
    $("#photo_modal").addClass("animationLeft")
    setTimeout(function(){
        $("#photo_modal").removeClass("animationLeft")
    },1000)
   }
   else{

       if(NextDivImg.length===1){
           
        $("#photo_modal").attr("src", NextDivImg.attr("src"));
        NextDivImg.addClass("act")
        $("#photo_modal").addClass("animationLeft")
        setTimeout(function(){
            $("#photo_modal").removeClass("animationLeft")
        },1000)
       }else{
           
        $("#photo_modal").attr("src", FisrtImg.attr("src"));
        FisrtImg.addClass("act")
       }
   }
})
// Modal RightClick //

// Modal LeftClick //
 $(".fas.fa-angle-left").click(function(){
    var imgactiv = $(".act");
    imgactiv.removeClass("act");
    var PrevElemImg=imgactiv.parent().prev().find(".im");
    var PrevDivImg=imgactiv.parent().parent().parent().prev().find(".divimg").find("div:last-child").find(".im");
    var LastImg=$(".col-md-9 .col-md-3:last-child .divimg .divimg1 .im");

   if(PrevElemImg.length===1){  
       
    $("#photo_modal").attr("src", PrevElemImg.attr("src"));
    PrevElemImg.addClass("act");
    $("#photo_modal").addClass("animationRight")
    setTimeout(function(){
        $("#photo_modal").removeClass("animationRight")
    },1000)
   }
   else{

       if(PrevDivImg.length===1){
           
        $("#photo_modal").attr("src", PrevDivImg.attr("src"));
        PrevDivImg.addClass("act")
        $("#photo_modal").addClass("animationRight")
        setTimeout(function(){
            $("#photo_modal").removeClass("animationRight")
        },1000)
       }else{
           
        $("#photo_modal").attr("src", LastImg.attr("src"));
        LastImg.addClass("act")
       }
   }
 })
// Modal LeftClick //

// bootstrap3 nav


// bootstrap3 nav

})